---
title: Assignment 1
subtitle: Computer performance, reliability, and scalability calculation
author: Aaron Drexler
---

## 1.2 

#### a. Data Sizes

| Data Item                                     | Size per Item | 
|-----------------------------------------------|--------------:|
| 1) 128 character message.                     | 128 Bytes     |
| 2) 1024x768 PNG image                         | 2.25 MB       |
| 3) 1024x768 RAW image                         | 3.75 MB       | 
| 4) HD (1080p) HEVC Video (15 minutes)         | 36 MB         |
| 5) HD (1080p) Uncompressed Video (15 minutes) | 36000 MB      |
| 6) 4K UHD HEVC Video (15 minutes)             | 228 MB        |
| 7) 4k UHD Uncompressed Video (15 minutes)     | 228000 MB     |
| 8) Human Genome (Uncompressed)                | 12.8 GB       |

## 1) 1 character = 1 Byte;  128 characters = 128 Bytes.

## 2) a) Pixels: 1024 * 768=786,432 pixels
##    b) Depth of PNG image = 24 bits = 3 bytes 
##    c) ((786,432*3)/1024)/1024= 2.25 MB 

## 3) a) Pixels: 1024 * 768=786,432 pixels. 786432/1000000=0.78 MP 
##    b) Raw image's depth = 5
##    c) ((786,432 * 5)/1024)/1024 = 3.75 MB

## 4) a)HEVC Frames per sec: 30 fps and 8 bit depth
##    b)video length(15 miniutes = 15* 60 s= 900 
##    c)size calculation: 900 sec * 30 fps 1290*1080*8/8/1000/1024/1024, size is approximately 36 MB.

## 5) Uncompressed Video: 1000 times HEVC Video = 36,000 MB.

## 6) 4K = 4096 -> 4096*2160*8/8/1000/1024/1024, size is approximately 228 MB.

## 7) Uncompressed Video: 1000 * 4K = 228,000 MB.

## 8) Human Genome: Humans have 22 unique chromosomes x 2 = 44 ->  large chromosome = 300 MB -> small chromosome = 50 MB -> 44*300=13200  -> 13200/1024=12.8 GB

## reference: https://stackoverflow.com/questions/8954571/how-much-storage-would-be-required-to-store-a-human-genome

#### b. Scaling

|                                              | Size     | # HD | 
|----------------------------------------------|---------:|-----:|
| 1) Daily Twitter Tweets (Uncompressed)       | 59.6 GB  |1     |
| 2) Daily Twitter Tweets (Snappy Compressed)  | 40 GB    |1     |
| 3) Daily Instagram Photos                    | 100TB    |33    |
| 4) Daily YouTube Videos                      | 99 TB    |32    |
| 5) Yearly Twitter Tweets (Uncompressed)      | 21.2 TB  |7     |
| 6) Yearly Twitter Tweets (Snappy Compressed) | 14.25 TB |4     |
| 7) Yearly Instagram Photos                   | 36500 TB |13272 |
| 8) Yearly YouTube Videos                     | 36135 TB |12045 |

## Notes
## a) Daily Twitter= 500,000,000 Tweets
## b) 1 Tweet = 128 Characters
## c) Daily Instagram = 100 Million Photos

## 1) 500,000,000*128= 64000000000 -> ((64000000000/1024)/1024)/1024= 59.6 GB

## 2) Snappy Compressed: compression ratio  1.5 : 1.7 times for plain text.  59.6GB : ~40GB (reference a)

## 3) 100 million photos, size = 1MB
##    100,000,000 *1= 100,000,000 MB= 100 TB (Reference b)

## 4) Daily Video = 500 * 60 * 24 = 720000 hrs
##    length 15 min: 720000 * 4 = 2880000
##    2880000 * 36MB = 103680000 MB= 98.87 TB

## 5) 59.6 (daily) * 365  = 21,754 GB = 21.2 TB

## 6) 40 (daily) * 365 = 14,600 GB = 14.25 TB

## 7) 100 (Daily) TB * 365 = 36,500 TB

## 8) 99 (Daily) TB * 365 = 36,135 TB

## reference:   a)https://www.infoq.com/news/2011/04/Snappy/#:~:text=The%20high%20compression%20speed%20is,other%20already%2Dcompressed%20data%E2%80%9D
## b)https://help.instagram.com/1631821640426723

#### c. Reliability
|                                    | # HD | # Failures |
|------------------------------------|-----:|-----------:|
| Twitter Tweets (Uncompressed)      | 7    |<1          |
| Twitter Tweets (Snappy Compressed) | 5    |<1          |
| Instagram Photos                   | 8213 |73          |
| YouTube Videos                     | 11388|101         |
failure rate used = 0.89%: #_failures= #HD*Failure_rate

#### d. Latency

|                           | One Way Latency      |
|---------------------------|---------------------:|
| Los Angeles to Amsterdam  | 29.8 ms                |
| Low Earth Orbit Satellite | 6.7 ms              |
| Geostationary Satellite   | 119.4 ms               |
| Earth to the Moon         | 1282.2 ms              |
| Earth to Mars             | 15.6 minutes        | 

## Notes
## a)speed of light = 299,792 Km/s
## b)LA -> Amsterdam = 8,963 km
## c) Low Earth Orbit = 2,000 km
## d) Geostationary = 35,786 km
## e) Earth -> Moon = 384,400 km
## f) Earth -> Mars = 281,313,331 km

## One way Latency = distance * Speed of light
## 8933 * 1000/299,792= 29.8 ms
## 2000 * 1000/299792= 6.7 ms
## 35786 * 1000/299792 = 119.4 ms
## 384400 * 1000/299792 = 1282.2 ms
## 281,313,331 * 1000/299792 =938,361.7 ms = 15.6 min

## References: 
## https://www.nasa.gov/leo-economy/faqs 
## https://www.trippy.com/distance/Los-Angeles-to-Amsterdam
## https://www.space.com/15830-light-speed.html
## https://www.sciencedirect.com/topics/earth-and-planetary-sciences/geostationary-satellite
## https://spaceplace.nasa.gov/moon-distance/en/
## https://mars.nasa.gov/all-about-mars/night-sky/close-approach/
